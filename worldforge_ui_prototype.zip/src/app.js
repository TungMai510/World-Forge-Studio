import { UIController } from './ui/layout.js';

document.addEventListener('DOMContentLoaded', () => {
    console.log("WorldForge Studio UI Framework Bootstrapped.");
    const ui = new UIController();
    ui.init();
});
