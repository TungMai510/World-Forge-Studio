export class UIController {
    constructor() {
        this.bottomPanel = document.getElementById('bottom-panel');
    }

    init() {
        this.setupTooltips();
        // Placeholder for future UI bindings
    }

    setupTooltips() {
        // Implementation for custom tooltips can go here
        // Currently relying on native browser title attributes for prototype
    }
}
